

const express = require('express')
// const { modelName } = require('../models/user.models')

const router = express.Router()
const User = require('../models/user.models')

router.get("/", async (req, res) => {
    try {
        const users = await User.find().lean().exec()
        res.status(201).send("sa")
    }
    catch (err) {
        res.status(500).send({ message: err.message })
    }
})

router.post("/", async (req, res) => {
    try {
        console.log(req.body)

        const user = await User.create(req.body)
        res.send(" Succesfully Registered")
    }
    catch (err) {
        res.status(500).send({ message: err.message })
    }
})

module.exports = router